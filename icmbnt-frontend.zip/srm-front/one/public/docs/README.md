# Conference Forms

This directory contains the registration and copyright forms needed for the ICMBNT-2025 conference.

- ICMBNT_2025_Registration_Form.pdf - Registration form for conference participants
- ICMBNT_2025_Copyright_Form.pdf - Copyright transfer form for authors

Please ensure these files are kept up to date with the latest versions.
